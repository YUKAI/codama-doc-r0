# Copyright (c) 2018 NTT DOCOMO, Inc. All Rights Reserved.
# coding: utf-8
from .NluMetaData import NluMetaData
import threading


class CachedData:
    """ メタデータのキャッシュクラス """
    LOCK = threading.Lock()

    def __init__(self):
        self.shouldReceiveCounter = 0
        self.metaData = None

    def update(self, metadata):
        if isinstance(metadata, NluMetaData):
            self.decrement_counter()
            self.metaData = metadata
        else:
            pass

    def increment_counter(self):
        with CachedData.LOCK:
            self.shouldReceiveCounter += 1

    def decrement_counter(self):
        with CachedData.LOCK:
            self.shouldReceiveCounter -= 1

    def is_cached(self):
        if self.metaData is not None:
            return True
        else:
            return False

    def cache_failed(self):
        with CachedData.LOCK:
            if self.shouldReceiveCounter == 0:
                return False
            else:
                return True

    def clear(self):
        with CachedData.LOCK:
            self.shouldReceiveCounter = 0
            self.metaData = None

    def tojson(self):
        retval = None
        if self.metaData is not None:
            retval = self.metaData.tojson()
        return retval
