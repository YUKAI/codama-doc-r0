# Copyright (c) 2018 NTT DOCOMO, Inc. All Rights Reserved.
# coding: utf-8
import json
from datetime import datetime as dt


class Location:
    """ 緯度・経度クラス """
    def __init__(self, lat=None, lon=None):
        self.lat = lat
        self.lon = lon


class InvalidMetaDataException(ValueError, object):
    """ エラー通知クラス """
    def __init__(self, msg):
        super(InvalidMetaDataException, self).__init__()
        self.msg = msg

    def __str__(self):
        return repr(self.msg)


class NluMetaData:
    """ NLUに送信するメタデータ """

    # 定数値
    CLIENT_VER = "1.0.4"
    VOICE_TEXT_META_DATA = "#METADATA"
    DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
    APP_RECEIVE_TIME = "appRecvTime"
    APP_SEND_TIME = "appSendTime"
    LANGT = ("ja-JP", "en-US", "en-JP", "zh-JP", "zh-CN")

    # インストラクター
    def __init__(self):
        # クライアントバージョン情報
        self.clientVer = None

        # 指定言語選択
        self.language = None

        # 初期発話フラグ
        self.initTalkingFlag = None

        # 初期発話トピックID
        self.initTopicId = None

        # 音声認識結果
        self.voiceText = None

        # GPS(緯度/経度)
        self.location = None

        # クライアント情報
        self.clientData = {}

        # 応答時刻
        self.appRecvTime = None

        # 発話時刻
        self.appSendTime = None

        # 案件固有情報
        self.projectSpecific = {}

        # キャッシュフラグ
        self.cacheFlag = None

    # JSON情報をインスタンスに設定
    def setjson(self, jsonstr):
        try:
            jsondict = json.loads(jsonstr)
        except ValueError:
            raise

        # クライアントバージョン情報
        if "clientVer" in jsondict:
            self.clientVer = jsondict["clientVer"]

        # 指定言語選択
        if "language" in jsondict:
            if jsondict["language"] in NluMetaData.LANGT:
                self.language = jsondict["language"]
            else:
                raise InvalidMetaDataException(
                    "language:" + jsondict["language"] + "is invalid.")

        # 初期発話フラグ
        if "initTalkingFlag" in jsondict:
            self.initTalkingFlag = jsondict["initTalkingFlag"]

        # 初期発話トピックID
        if "initTopicId" in jsondict:
            self.initTopicId = jsondict["initTopicId"]

        # 音声認識結果
        if "voiceText" in jsondict:
            self.voiceText = jsondict["voiceText"]

        # GPS(緯度/経度)
        if "location" in jsondict:
            locdict = jsondict["location"]
            if self.location is None:
                self.location = Location()
            if "lat" in locdict:
                self.location.lat = float(locdict["lat"])
            if "lon" in locdict:
                self.location.lon = float(locdict["lon"])

        # クライアント情報
        if "clientData" in jsondict:
            self.clientData = jsondict["clientData"]

        # 応答時刻
        if NluMetaData.APP_RECEIVE_TIME in jsondict:
            drtime = deserialize(jsondict[NluMetaData.APP_RECEIVE_TIME])
            jsondict[NluMetaData.APP_RECEIVE_TIME] = drtime

        # 発話時刻
        if NluMetaData.APP_SEND_TIME in jsondict:
            dstime = deserialize(jsondict[NluMetaData.APP_SEND_TIME])
            jsondict[NluMetaData.APP_SEND_TIME] = dstime

        # 案件固有情報
        self.projectSpecific = {}
        if "projectSpecific" in jsondict:
            self.projectSpecific = jsondict["projectSpecific"]

        # キャッシュ情報
        if "cacheFlag" in jsondict:
            self.cacheFlag = jsondict["cacheFlag"]

    # 音声認識結果とクライアント情報を指定
    def set_client_data(self, voicetext, clientdata):
        self.voiceText = voicetext
        self.cacheFlag = False
        # クライアント情報を指定
        if isinstance(clientdata, dict):
            # clientDataがdictならそのまま設定
            self.clientData = clientdata
        elif isinstance(clientdata, str):
            # clientDataがstrならdict化して設定
            try:
                self.clientData = json.loads(clientdata)
            except ValueError:
                self.clientData = {}
                raise
        else:
            self.clientData = {}
            raise InvalidMetaDataException("unknown instance")

    @staticmethod
    def fromjson(jsonstr):
        metadata = NluMetaData()
        metadata.setjson(jsonstr)
        return metadata

    # JSON文字列に変換
    # return JSON文字列
    # throws
    def tojson(self):
        # 辞書データを生成
        jsondata = {}

        # クライアントバージョン情報
        if self.clientVer:
            jsondata["clientVer"] = self.clientVer

        # 指定言語選択
        if self.language:
            if self.language in NluMetaData.LANGT:
                jsondata["language"] = self.language
            else:
                raise InvalidMetaDataException("invalid language")

        # 初期発話フラグ
        if self.initTalkingFlag is not None:
            jsondata["initTalkingFlag"] = self.initTalkingFlag

        # 初期発話トピックID
        if self.initTopicId:
            jsondata["initTopicId"] = self.initTopicId
        if self.voiceText:
            jsondata["voiceText"] = self.voiceText

        # GPS(緯度/経度)
        if self.location and self.location.lat and self.location.lon:
            locdict = {}
            locdict["lat"] = str(self.location.lat)
            locdict["lon"] = str(self.location.lon)
            jsondata["location"] = locdict

        # クライアント情報
        if self.clientData:
            jsondata["clientData"] = self.clientData

        # 応答時刻
        if self.appRecvTime:
            jsondata["appRecvTime"] = serialize(self.appRecvTime)

        # 発話時刻
        if self.appSendTime:
            jsondata["appSendTime"] = serialize(self.appSendTime)

        # 案件固有情報
        if self.projectSpecific:
            jsondata["projectSpecific"] = self.projectSpecific

        # キャッシュフラグ
        if self.cacheFlag is not None:
            jsondata["cacheFlag"] = self.cacheFlag

        return json.dumps(jsondata)

    # メタデータの妥当性を検証
    def validate(self):
        if self.initTalkingFlag is True and self.initTopicId is None:
            self.required("initTopicId")
        if self.location:
            if self.location.lat is None and self.location.lon:
                self.required("location.lat")
            elif self.location.lat and self.location.lon is None:
                self.required("location.lon")
        return

    # エラー時にExceptionをなげる
    def required(self, fieldname):
        raise InvalidMetaDataException(fieldname + " is required.")


def deserialize(strdatetime):
    """ 文字列をstrからdatetimeに変換する """
    return dt.strptime(strdatetime, NluMetaData.DATE_FORMAT)


def serialize(tdatetime):
    """ 文字列をdatetimeからstrに変換する """
    return tdatetime.strftime(NluMetaData.DATE_FORMAT)
