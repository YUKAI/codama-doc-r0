# Copyright (c) 2018 NTT DOCOMO, Inc. All Rights Reserved.
# coding: utf-8
import sys
import logging
from logging import getLogger, StreamHandler, Formatter
import threading


class LogUtil:
    """ メタデータのキャッシュクラス """

    def __init__(self, name):
        self.logger = getLogger(name)
        self.logger.setLevel(logging.CRITICAL)

        h = StreamHandler(sys.stdout)
        h.setLevel(logging.CRITICAL)

        fmt = Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        h.setFormatter(fmt)

        self.logger.addHandler(h)

    def d(self, msg):
        self.logger.debug(threading.currentThread().getName() + " - " + msg)

    def i(self, msg):
        self.logger.info(threading.currentThread().getName() + " - " + msg)

    def w(self, msg):
        self.logger.warn(threading.currentThread().getName() + " - " + msg)

    def e(self, msg):
        self.logger.error(threading.currentThread().getName() + " - " + msg)

    def f(self, msg):
        self.logger.fatal(threading.currentThread().getName() + " - " + msg)
