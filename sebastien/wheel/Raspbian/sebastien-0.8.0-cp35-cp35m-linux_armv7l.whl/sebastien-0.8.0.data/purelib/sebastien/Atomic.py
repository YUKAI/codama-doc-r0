# Copyright (c) 2018 NTT DOCOMO, Inc. All Rights Reserved.
# coding: utf-8
import threading


class Atomic:
    def __init__(self, value):
        self.value = value
        self.lock = threading.Lock()

    def set(self, val):
        self.lock.acquire()
        self.value = val
        self.lock.release()

    def compareandset(self, val1, val2):
        self.lock.acquire()
        retval = False
        if self.value == val1:
            self.value = val2
            retval = True
        self.lock.release()
        return retval

    def get(self):
        self.lock.acquire()
        retval = self.value
        self.lock.release()
        return retval
