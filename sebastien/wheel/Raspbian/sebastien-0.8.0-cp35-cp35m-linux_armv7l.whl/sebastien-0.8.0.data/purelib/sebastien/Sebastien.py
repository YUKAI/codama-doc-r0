# Copyright (c) 2018 NTT DOCOMO, Inc. All Rights Reserved.
# coding: utf-8
from . import flow
from .NluMetaData import NluMetaData, InvalidMetaDataException
from .CachedData import CachedData
from .LogUtil import LogUtil
from .Atomic import Atomic
import json

from .flow import EventHandler
from .flow import ErrorEventHandler
from .flow import StringEventHandler
from .flow import IntEventHandler
from .flow import DoubleEventHandler

class Sebastien:
    """ Sebastien SDK """

    # 定数値
    ERRORCODE_INTERNAL_FLOW_INTERNAL = 143
    JSON_PROCESSING_ERROR_CODE = 146
    DEFAULT_PLAY_END_DELAY_TIME = 0.3
    POLL_NUM = 100

    # LogUtil
    log = LogUtil(__name__)

    selfinstance = None

    # コンストラクタ
    def __init__(self, configname=None):
        Sebastien.selfinstance = self
        Sebastien.log.d("__init__")
        self.f = flow.Flow()
        self.cachedData = CachedData()
        if configname is not None:
            self.f.load_config_file(configname)

        # SDKの状態
        self.failed = Atomic(False)
        self.starting = Atomic(False)
        self.stopping = Atomic(False)
        self.started = Atomic(False)

        self.pStartReq = Atomic(False)
        self.pStopReq = Atomic(False)

        self.micMute = False

        # Blockの初期化
        self.play_block = None
        self.play_start_block = None
        self.play_end_block = None
        self.record_block = None
        self.mute_block = None
        self.unmute_block = None
        self.play_cancel_block = None
        self.vad_start_block = None
        self.vad_end_block = None
        self.vad_meta_in_block = None

        self.client_block = None
        self.text_in_block = None
        self.meta_in_block = None
        self.text_out_block = None
        self.meta_out_block = None
        self.cached_data_in_block = None
        self.cached_data_out_block = None

        self.resampler_block = None
        self.sound_out_block = None
        self.gain_hook_block = None
        self.gain_control_block = None

        # Edgeの初期化
        self.playStartEdge = None
        self.playEndEdge = None
        self.text2server = None
        self.meta2server = None
        self.cachedData2server = None
        self.text2client = None
        self.meta2client = None
        self.cachedData2client = None
        self.vadstart2client = None
        self.vadend2client = None
        self.vadMetaIn2metaOut = None
        self.muteEdge = None
        self.unmuteEdge = None
        self.playCancelEdge = None
        self.playClearEdge = None
        self.resamplerClearEdge = None
        self.oggClearEdge = None
        self.micGain2ClientEdge = None
        self.gainHookEdge = None
        self.resampler2playEdge = None
        self.soundout2playEdge = None

        # コールバック先の保存
        self.cb_on_cache_failed = None
        self.cb_on_gain_value = None
        self.cb_on_play_end = None
        self.cb_on_play_start = None
        self.cb_on_sound_out = None
        self.cb_on_text_out = None
        self.cb_on_meta_out = None

        self.cb_on_start = Atomic(None)
        self.cb_on_failed = Atomic(None)
        self.cb_on_stop = Atomic(None)
        self.cb_on_start_post = Atomic(None)
        self.cb_on_failed_post = Atomic(None)
        self.cb_on_stop_post = Atomic(None)

        return

    # デストラクタ
    def __del__(self):
        Sebastien.selfinstance = None

    # 合成音声の再生をキャンセルする
    def cancel_play(self):
        Sebastien.log.d("cancel_play")
        if (self.starting.get() or
                self.stopping.get() or
                not self.started.get()):
            Sebastien.log.e("invalid state")
            return
        self.play_stop_block.notify("")
        return

    # SDKの内部ステータスを返却する.
    # @return 停止状態の場合は{@code 0},
    #         開始中の場合は{@code 1},
    #         開始状態の場合は{@code 2},
    #         停止中の場合は{@code 3}を返却.
    def get_internal_state(self):
        if self.failed.get():
            return 3
        elif self.starting.get():
            return 1
        elif self.stopping.get():
            return 3
        elif self.started.get():
            return 2
        else:
            return 0

    # 初期化を実施する。
    # ホスト名等のパラメータ設定、イベントハンドラの設定が完了した後に本メソッドを呼び出す。
    # その後startメソッドが呼び出し可能となる。
    def init(self):
        Sebastien.log.d("init")

        # Blockの生成/設定
        self.client_block = flow.Block("client")
        self.play_block = flow.Block("play")
        self.play_start_block = flow.Block("playStartBlock")
        self.play_end_block = flow.Block("playEndBlock")
        self.record_block = flow.Block("record")
        self.mute_block = flow.Block("mute")
        self.unmute_block = flow.Block("unmute")
        self.text_in_block = flow.Block("text_in")
        self.meta_in_block = flow.Block("meta_in")
        self.cached_data_in_block = flow.Block("cachedData_in")
        self.text_out_block = flow.Block("text_out")
        self.meta_out_block = flow.Block("meta_out")
        self.cached_data_out_block = flow.Block("cachedData_out")
        self.cached_data_out_block.slot(StringEventHandler(self.handler_on_cached_data_local))
        self.vad_start_block = flow.Block("vadStartBlock")
        self.vad_start_block.slot(IntEventHandler(self.handler_on_vad_start_local))
        self.vad_end_block = flow.Block("vadEndBlock")
        self.vad_end_block.slot(IntEventHandler(self.handler_on_vad_end_local))
        self.vad_meta_in_block = flow.Block("vadMetaInBlock")
        self.play_stop_block = flow.Block("play_stop")

        # Edgeの生成/設定
        self.playStartEdge = flow.Edge()
        self.playStartEdge.from_(self.play_block, "play_start")
        self.playStartEdge.to(self.play_start_block)
        self.playEndEdge = flow.Edge()
        self.playEndEdge.from_(self.play_block, "play_end")
        self.playEndEdge.to(self.play_end_block)
        self.text2server = flow.Edge("text2server")
        self.text2server.from_(self.text_in_block)
        self.text2server.to(self.client_block)
        self.meta2server = flow.Edge("meta2server")
        self.meta2server.from_(self.meta_in_block)
        self.meta2server.to(self.client_block)
        self.cachedData2server = flow.Edge("cachedData2server")
        self.cachedData2server.from_(self.cached_data_in_block)
        self.cachedData2server.to(self.client_block)
        self.text2client = flow.Edge("text2client")
        self.text2client.from_(self.client_block)
        self.text2client.to(self.text_out_block)
        self.meta2client = flow.Edge("meta2client")
        self.meta2client.from_(self.client_block)
        self.meta2client.to(self.meta_out_block)
        self.cachedData2client = flow.Edge("cachedData2client")
        self.cachedData2client.from_(self.client_block)
        self.cachedData2client.to(self.cached_data_out_block)
        self.vadstart2client = flow.Edge("vadstart2client")
        self.vadstart2client.from_(self.client_block)
        self.vadstart2client.to(self.vad_start_block)
        self.vadend2client = flow.Edge("vadend2client")
        self.vadend2client.from_(self.client_block)
        self.vadend2client.to(self.vad_end_block)
        self.vadMetaIn2metaOut = flow.Edge("vadmetain2metaout")
        self.vadMetaIn2metaOut.from_(self.vad_meta_in_block)
        self.vadMetaIn2metaOut.to(self.meta_out_block)
        self.muteEdge = flow.Edge("mute_edge")
        self.muteEdge.from_(self.mute_block)
        self.muteEdge.to(self.record_block, "on_mute")
        self.unmuteEdge = flow.Edge("unmute_edge")
        self.unmuteEdge.from_(self.unmute_block)
        self.unmuteEdge.to(self.record_block, "on_unmute")
        self.playCancelEdge = flow.Edge("play_cancel_edge")
        self.playCancelEdge.from_(self.play_stop_block)
        self.playClearEdge = flow.Edge("play_clear_edge")
        self.playClearEdge.from_(self.play_stop_block)
        self.resamplerClearEdge = flow.Edge("resampler_clear_edge")
        self.resamplerClearEdge.from_(self.play_stop_block)
        self.oggClearEdge = flow.Edge("ogg_clear_edge")
        self.oggClearEdge.from_(self.play_stop_block)

        return

    # HFPが有効か否かを返却。常に無効。
    def is_enabled_hfp(self):
        Sebastien.log.d("is_enabled_hfp")
        return False

    # マイクをミュートし、ユーザーの発話をサーバーに送信しないように設定する。
    def mute(self):
        Sebastien.log.d("mute")
        if (self.starting.get() or
                self.stopping.get() or
                not self.started.get()):
            Sebastien.log.e("invalid state")
            return
        self.mute_block.notify("")
        return

    # マイクのミュートを解除し、ユーザーの発話をサーバーに送信するように設定する
    def unmute(self):
        Sebastien.log.d("unmute")
        if (self.starting.get() or
                self.stopping.get() or
                not self.started.get()):
            Sebastien.log.d("invalid state")
            return
        self.unmute_block.notify("")
        return

    # NLUメタデータを送信。
    # @param metaData NLUメタデータ
    def put_meta(self, data):
        Sebastien.log.d("putMeta")
        if isinstance(data, NluMetaData):
            try:
                self.put_meta_inner(data)
            except ValueError:
                Sebastien.log.e("ValueError")
                raise
        elif isinstance(data, str) or isinstance(data, dict):
            metadata = NluMetaData()
            try:
                metadata.set_client_data(NluMetaData.VOICE_TEXT_META_DATA,
                                         data)
                self.put_meta_inner(metadata)
            except ValueError:
                Sebastien.log.e("ValueError")
                raise
        else:
            Sebastien.log.e("%s" % (type(data)))
            raise InvalidMetaDataException("meta is unknown type")
        return

    def put_meta_inner(self, metadata):
        if (self.starting.get() or
                self.stopping.get() or
                not self.started.get()):
            Sebastien.log.e("invalid state")
            return
        metadata.validate()
        json = metadata.tojson()
        Sebastien.log.d("json:" + json)
        if metadata.cacheFlag:
            self.cachedData.increment_counter()
        self.meta_in_block.notify(json)
        return

    # 発話テキスト情報をサーバーに送信する。
    # @param text 発話テキスト情報
    def put_text(self, text):
        Sebastien.log.d("put_text : " + text)
        if (self.starting.get() or
                self.stopping.get() or
                not self.started.get()):
            Sebastien.log.e("invalid state")
            return
        self.text_in_block.notify(text)
        return

    # KeyとValueを設定する。
    # @param key
    # @param value
    def set(self, key, value):
        if isinstance(value, bool):
            if value:
                Sebastien.log.d("set : " + key + ", value(boolean) : True")
            else:
                Sebastien.log.d("set : " + key + ", value(boolean) : False")
        elif isinstance(value, int):
            Sebastien.log.d("set : " + key + ", value(int) : " + str(value))
        elif isinstance(value, float):
            Sebastien.log.d("set : " + key + ", value(float) : " + str(value))
        elif isinstance(value, str):
            Sebastien.log.d("set : " + key + ", value(str) : " + value)
        else:
            # boolean, int, double, str, python function以外は無効
            Sebastien.log.e("set : " + key + ", invalid value!")
            return
#        elif isinstance(value, str):
#            Sebastien.log.d("set : " + key + ", value(str) : " + value
#       //TODO python function

        self.f.set(key, value)
        return

    # UDSから取得したアクセストークンを設定する。アクセストークンが適切に設定されていないとSDKの提供する機能を利用することができない。
    # @param accesstoken 設定するアクセストークンの値
    def set_access_token(self, accesstoken):
        Sebastien.log.d("set_access_token : " + accesstoken)
        self.f.set("AccessToken", accesstoken)
        return

    # SDK接続先サーバーのホスト名を設定する。
    # @param hostname 接続先のホスト名（例："spf.sebastien.mobi"）
    def set_host(self, hostname):
        Sebastien.log.d("set_host : " + hostname)
        self.f.set("Host", hostname)
        return

    # SDK接続先サーバーのポート番号を設定する。
    # @param port 接続ポート番号（例：8001）
    def set_port(self, port):
        Sebastien.log.d("set_port : " + str(port))
        self.f.set("Port", port)
        return

    # SDK接続先のURL Pathを設定する
    # @param urlpath URLパス（例："/echo"）
    def set_url_path(self, urlpath):
        Sebastien.log.d("set_url_path : " + urlpath)
        self.f.set("URLPath", urlpath)
        return

    # start時にマイクをmute状態にするか否かを設定する。
    # @param micmute Trueを指定した場合はstart時にマイクがmute状態となる
    def set_mic_mute(self, micmute):
        Sebastien.log.d("micMute : " + str(micmute))
        self.micMute = micmute
        return

    # 合成音声を受信した際に呼ばれるメソッドを設定する.
    # @param callback イベントハンドラ
    def set_on_sound_out(self, callback):
        Sebastien.log.d("set_on_sound_out")
        self.cb_on_sound_out = callback

        if self.sound_out_block is None:
            self.sound_out_block = flow.Block("soundout", "audio")
            self.sound_out_block.slot(Sebastien.h_on_sound_out)

        if self.resampler_block is None:
            self.resampler_block = flow.Block("resampler2play")

        if self.resampler2playEdge is None:
            self.resampler2playEdge = flow.Edge("resampler2play")

        if self.soundout2playEdge is None:
            self.soundout2playEdge = flow.Edge("soundout2play", "audio")

        self.resampler2playEdge.from_(self.resampler_block)
        self.resampler2playEdge.to(self.sound_out_block)
        self.soundout2playEdge.from_(self.sound_out_block)
        self.soundout2playEdge.to(self.play_block)

    @staticmethod
    def h_on_sound_out(i, shorts, i1, s):
        if Sebastien.selfinstance:
            Sebastien.log.d("selfinstance")
            Sebastien.selfinstance.h_on_sound_out_local(i, shorts, i1, s)

    def h_on_sound_out_local(self, i, shorts, i1, s):
        if self.cb_on_sound_out:
            self.cb_on_sound_out(i, shorts, i1, s)
        self.sound_out_block.notify(i, shorts, i1, s)

    def handler_text_out_local(self, msg):
        Sebastien.log.d("handler_text_out_local:" + msg)
        if self.cb_on_text_out:
            self.cb_on_text_out(msg)

    # 対話テキストを受信した際に呼ばれるメソッドを設定する。
    # @param onTextOut 対話テキスト受信時に呼ばれるイベントハンドラ
    def set_on_text_out(self, callback):
        Sebastien.log.d("set_on_text_out")
        self.cb_on_text_out = callback
        self.text_out_block.slot(StringEventHandler(self.handler_text_out_local))
        return

    def handler_on_vad_end_local(self, msg):
        jsondata = {}
        jsondata["version"] = ""
        jsondata["type"] = "speech_recognition_vad_end"
        self.vad_meta_in_block.notify(json.dumps(jsondata))

    def handler_on_vad_start_local(self, msg):
        jsondata = {}
        jsondata["version"] = ""
        jsondata["type"] = "speech_recognition_vad_start"
        self.vad_meta_in_block.notify(json.dumps(jsondata))

    def handler_on_play_end_local(self, msg):
        if self.cb_on_play_end:
            self.cb_on_play_end("")

    # 合成音声の再生が終わる際に呼ばれるメソッドを設定する。対話キャラクターの口パク終了時等を検知する際に利用する。
    # @param onPlayEnd 合成音声終了時に呼ばれるイベントハンドラ
    def set_on_play_end(self, callback):
        Sebastien.log.d("set_on_play_end")
        self.cb_on_play_end = callback
        self.play_end_block.slot(IntEventHandler(self.handler_on_play_end_local))
        return

    def handler_on_play_start_local(self, msg):
        if self.cb_on_play_start:
            self.cb_on_play_start("")

    # 合成音声の再生が始まる際に呼ばれるメソッドを設定する。対話キャラクターの口パク開始等を検知する際に利用する。
    # @param callback 合成音声開始時に呼ばれるイベントハンドラ
    def set_on_play_start(self, callback):
        Sebastien.log.d("set_on_play_start")
        self.cb_on_play_start = callback
        self.play_start_block.slot(IntEventHandler(self.handler_on_play_start_local))
        return

    def handler_meta_out_local(self, meta):
        Sebastien.log.d("handler_meta_out_local:" + meta)
        self.cb_on_meta_out(meta)

    # メタ情報を受信した際に呼ばれるメソッドを設定する。
    # @param callback メタ情報受信時に呼ばれるイベントハンドラ
    def set_on_meta_out(self, callback):
        Sebastien.log.d("set_on_meta_out")
        self.cb_on_meta_out = callback
        self.meta_out_block.slot(StringEventHandler(self.handler_meta_out_local))
        return

    # MicGain値を取得した際に呼ばれるメソッドを設定する.
    # @param callback イベントハンドラ
    def set_on_gain_value(self, callback):
        Sebastien.log.d("set_on_gain_value")
        self.cb_on_gain_value = callback

        if self.gain_hook_block is None:
            self.gain_hook_block = flow.Block("gainHookBlock")
            self.gain_hook_block.slot(DoubleEventHandler(self.handler_on_gainvalue_local))

        if self.gain_control_block is None:
            self.gain_control_block = flow.Block("gc")

        if self.micGain2ClientEdge is None:
            self.micGain2ClientEdge = flow.Edge("micgain2client")

        if self.gainHookEdge is None:
            self.gainHookEdge = flow.Edge("gainHookEdge")

        self.micGain2ClientEdge.to(self.gain_hook_block)
        self.gainHookEdge.from_(self.gain_hook_block)
        self.gainHookEdge.to(self.gain_hook_block, "on_gain_change")

        return

    def handler_on_gainvalue_local(self, gainvalue):
        Sebastien.log.d("h_on_gainvalue_local" + str(gainvalue))
        if self.cb_on_gain_value:
            self.cb_on_gain_value(gainvalue)

    # SDKにキャッシュされたメタ情報が古く、Sebastien#start時にSDKにキャッシュされたメタ情報をSPFに送信できない場合に実行されるイベントハンドラを設定する。
    # @param callback イベントハンドラ
    def set_on_cache_failed(self, callback):
        Sebastien.log.d("set_on_cache_failed")
        self.cb_on_cache_failed = callback
        return

    # サーバと接続し対話を開始する。(polling無し)
    def handler_start_local(self):
        Sebastien.log.d("handler_start_local")
        self.starting.set(False)
        if self.cachedData.cache_failed():
            self.cachedData.clear()
            if self.cb_on_cache_failed is not None:
                self.cb_on_cache_failed()

        if self.micMute is False:
            self.unmute()

        if self.cb_on_start.get():
            self.cb_on_start.get()()
            self.cb_on_start.set(None)

        if self.pStopReq.get():
            self.stop(self.cb_on_stop_post.get())
            self.pStopReq.set(False)
            self.cb_on_stop_post.set(None)
        return

    def handler_failed_local(self, ecode, failstr):
        Sebastien.log.e("handler_failed:" + str(ecode) + "," + failstr)
        if self.failed.get():
            return
        if self.starting.get():
            self.pStopReq.set(False)
            self.cb_on_stop_post.set(None)
        if self.stopping.get():
            if self.pStartReq.get():
                self.start(self.cb_on_start_post.get(),
                           self.cb_on_failed_post.get())
                self.pStartReq.set(False)
                self.cb_on_start_post.set(None)
                self.cb_on_failed_post.set(None)

        self.failed.set(True)
        if self.cb_on_failed.get():
            self.cb_on_failed.get()(ecode, failstr)
            self.cb_on_failed.set(None)
        return

    def start(self, onstart, onfailed, with_polling_loop=True):
        Sebastien.log.d("start")
        if self.failed.get():
            self.cb_on_failed(Sebastien.ERRORCODE_INTERNAL_FLOW_INTERNAL,
                              "State is not acceptable to start.")
            return

        if self.stopping.get():
            self.cb_on_start_post.set(onstart)
            self.cb_on_failed_post.set(onfailed)
            self.pStartReq.set(True)
            return

        if self.started.get() or not self.starting.compareandset(False, True):
            if self.starting.get():
                self.pStopReq.set(False)
                self.cb_on_stop_post.set(False)
                self.cb_on_start.set(onstart)
                self.cb_on_failed.set(onfailed)
            return

        self.started.set(True)
        self.cb_on_start.set(onstart)
        self.cb_on_failed.set(onfailed)

        self.f.set("MicMute", True)

        self.f.start(EventHandler(self.handler_start_local),
                     ErrorEventHandler(self.handler_failed_local))

        if with_polling_loop:
            # SDK 内で poll を実施する
            while self.f.poll():
                pass

            self.started.set(False)
            self.starting.set(False)
            self.stopping.set(False)
            self.failed.set(False)

            if self.pStartReq.get():
                self.start(self.cb_on_start_post,
                           self.cb_on_failed_post)
                self.pStartReq.set(False)
                self.cb_on_start_post.set(None)
                self.cb_on_failed_post.set(None)

        return

    # flowにポーリングする
    def poll(self):
        Sebastien.log.d("poll")
        retval = True
        try:
            for i in range(Sebastien.POLL_NUM):
                if self.failed.get():
                    break;
                if not self.f.poll(False):
                    self.started.set(False)
                    self.starting.set(False)
                    self.stopping.set(False)
                    self.failed.set(False)
                    if self.pStartReq.get():
                        self.start(self.cb_on_start_post,
                                   self.cb_on_failed_post)
                        self.pStartReq.set(False)
                        self.cb_on_start_post.set(None)
                        self.cb_on_failed_post.set(None)
                    retval = False
                    break
        except Exception:
            import traceback
            traceback.print_exc()
        return retval

    # サーバと接続し対話を終了する。
    def handler_stop_local(self):
        Sebastien.log.d("handler_stop_local")
        self.starting.set(False)
        self.started.set(False)
        if self.cb_on_stop.get():
            self.cb_on_stop.get()()
            self.cb_on_stop.set(None)
        return

    def stop(self, onstop):
        Sebastien.log.d("stop")
        if self.failed.get():
            return
        if self.starting.get():
            self.cb_on_stop_post.set(onstop)
            self.pStopReq.set(True)
            return
        if self.started.get() is False:
            return
        if self.stopping.compareandset(False, True) is False:
            self.cb_on_stop.set(onstop)
            self.cb_on_start_post.set(None)
            self.pStartReq.set(False)
            self.cb_on_failed_post.set(None)
            return

        self.cb_on_stop.set(onstop)
        self.f.stop(EventHandler(self.handler_stop_local))
        return

    def handler_on_cached_data_local(self, json):
        Sebastien.log.d("handler_on_cached_data_local")
        metadata = NluMetaData()
        try:
            metadata.setjson(json)
            self.cachedData.update(metadata)
        except InvalidMetaDataException as e:
            Sebastien.log.e(e)
            pass
        return
